<?php
// Require theme functions
require get_stylesheet_directory() . '/inc/fn.php';

// Customize your functions
